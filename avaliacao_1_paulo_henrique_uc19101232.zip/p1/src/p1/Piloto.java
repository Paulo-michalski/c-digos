package p1;

public class Piloto {
	
//Atributo
	private String nome_piloto;
	
//Construtor
	Piloto(String nome_piloto){
		set_nome_piloto(nome_piloto);
	}
	
	
//Getter e setter
	public String get_nome_piloto() {
		return nome_piloto;
	}

	public void set_nome_piloto(String nome_piloto) {
		this.nome_piloto = nome_piloto;
	}
}
