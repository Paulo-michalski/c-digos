package p1;

public class Executora {
	//A executora chama o menu
	public static void main(String[] args) {
		Menu.menu();
	}

}
