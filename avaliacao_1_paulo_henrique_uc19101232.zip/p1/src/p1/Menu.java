package p1;

public class Menu {

	//Menu
		static void menu() {
			//Atributos
			int opcao = 0;
			int num_passagens = 0;
			int passagens_disponiveis = 8;
			String result;
			//Cria��o do piloto e do jatinho
			Piloto piloto = new Piloto("Comandante Amilton");
			Jatinho jato = new Jatinho(piloto);
			
			//O menu vai ficar aparecendo at� que a op��o colocada seja 0
			do {
				//Escolhas do menu
				opcao = View.solicitar_int("MENU", "Escolha a op��o desejada:\n"
						+ "0 - Sair.\n"
						+ "1 - Comprar passagem.\n"
						+ "2 - Excluir passagem.\n"
						+ "3 - Relat�rio das passagens compradas.\n"
						+ "Passagens disponiveis: " + passagens_disponiveis + ".\n");
				
				switch (opcao) {
				case 0: 
					//Sa�da do sistema
					View.exibir_mensagem("ADEUS!", "Obrigado, volte sempre!");
					break;
					
				case 1:
					//Compra da passagem
					if(num_passagens != 8) {
						boolean valida;
							try {
								//Coloca��o e valida��o dos dados inseridos pelo usu�rio
								int idade_passageiro = View.solicitar_int("IDADE PASSAGEIRO", "Digite a idade do passageiro:");
								Passageiro passageiro = new Passageiro(idade_passageiro);
								String nome_passageiro = View.solicitar_string("NOME PASSAGEIRO", "Digite o nome do passageiro: ");
								passageiro.set_nome_passageiro(nome_passageiro);
								passageiro.set_lugar_passageiro(num_passagens+1);
								//Chamada do pagamento da passagem
								do {
									valida = Util.compra_passagem();
								}while(valida == false);
								//Inserindo o passageiro na ArrayList de Jatinho
								jato.inserir_passageiro(passageiro);
								//Estes dois tipos est�o sempre mantendo o controle do n�mero de passagens e at� da permi��o de algumas fun��es como remover passagens e mostrar relat�rio
								num_passagens++;
								passagens_disponiveis--;
							} catch (IllegalArgumentException e) {
								//A exeption (Manu: [O defensor das porteiras!]) 
								View.exibir_exeption(e);
						}
					}else {
						//Quando o n�mero m�ximo de passagens � atingido essa mensagem � mostrada
						View.exibir_erro("Jatinho cheio!");
					}
					break;
					
				case 2:
					//� apenas permitido usar essa op��o se o n�mero de passagens for maior que 0
					if(num_passagens > 0) {
						try {
							//Mostra as passagens j� compradas
							result = jato.to_string_passageiros();
							int excluir = View.solicitar_int("Remover passagem", "Digite o n�mero da poltrona da passagem que deseja excluir:\n" + result);
							jato.remover_passageiro(excluir);
							num_passagens--;
							passagens_disponiveis++;
						} catch (IllegalArgumentException e) {
							View.exibir_exeption(e);
						}
					}else {
						View.exibir_erro("Nenhuma passagem foi comprada ainda!");
					}
					break;
				
				case 3:
					if(num_passagens != 0) {
						//Mostra o relat�rio de todas as passagens j� compradas, inclusive o piloto do jatinho
						result = jato.to_string_passageiros();
						View.exibir_mensagem("RELAT�RIO", result);
					}else {
						View.exibir_mensagem("RELAT�RIO", "Nenhuma passagem foi comprada ainda!");
					}
					break;
					
					//Essa � a mensagem que � retornada caso a op��o escolhida n�o seja nenhuma das 4 acima
				default:
					View.exibir_erro("Selecione apenas as op��es disponiveis!");
					break;
				}
			}while(opcao != 0);
		}
}
