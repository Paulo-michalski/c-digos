package p1;

import javax.swing.JOptionPane;

public class View {
	//Toda essa classe � apenas pra mostrar mensagens ou qualque coisa que seja visual
	//Metodos
		static void exibir_mensagem(String titulo, String msg) {
			JOptionPane.showMessageDialog(null, msg, titulo, JOptionPane.PLAIN_MESSAGE);
		}
		
		static String solicitar_string(String titulo, String msg) {
			return JOptionPane.showInputDialog(null, msg, titulo, JOptionPane.DEFAULT_OPTION);
		}
		
		static int solicitar_int(String titulo, String msg) {
			String retorno = JOptionPane.showInputDialog(null, msg, titulo, JOptionPane.INFORMATION_MESSAGE);
			return Integer.parseInt(retorno);
		}
		
		static float solicitar_float(String titulo, String msg) {
			String retorno = JOptionPane.showInputDialog(null, msg, titulo, JOptionPane.INFORMATION_MESSAGE);
			return Float.parseFloat(retorno);
		}
		
		static void exibir_erro(String erro) {
			JOptionPane.showMessageDialog(null, erro, "ERRO", JOptionPane.ERROR_MESSAGE);
		}
		
		static void exibir_exeption(IllegalArgumentException erro) {
			JOptionPane.showMessageDialog(null, erro, "ERRO", JOptionPane.ERROR_MESSAGE);
		}
}
