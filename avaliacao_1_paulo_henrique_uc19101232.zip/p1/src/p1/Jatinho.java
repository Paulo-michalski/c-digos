package p1;

import java.util.ArrayList;

public class Jatinho {

//Atributos
	private Piloto piloto;
	private ArrayList<Passageiro>passageiros = new ArrayList<Passageiro>();
	
//Construtor
	Jatinho(Piloto piloto){
		inserir_piloto(piloto);
	}
	
//Metodos
	public void inserir_passageiro(Passageiro passageiro) {
		this.passageiros.add(passageiro);
	}
	
	// Ao remover um passageiro da ArrayList ele j� arruma o lugar de cada passageiro
	public void remover_passageiro(int i) {
		int tamanho = this.passageiros.size();
		if(tamanho >= i && i > 0) {
			this.passageiros.remove(i-1);
			if(tamanho != i) {
				for (Passageiro passageiro : passageiros) {
					passageiros.get(i-1).set_lugar_passageiro(i);
					i++;
				}
			}
			//Se o n�mero colocado n�o existir nenhum passageiro na ArrayLit ele retorna esta exeption 
		}else {
			throw new IllegalArgumentException("[JATO]: Digite uma poltrona v�lida!");
		}
	}
	
	public void inserir_piloto(Piloto piloto) {
		this.piloto = piloto;
	}
	
	//Mostra todo o relat�rio do piloto do jatinho e seus passageiros com nome, idade e lugar
	public String to_string_passageiros() {
		int i = 0;
		String result = "Piloto: " + piloto.get_nome_piloto();
		for (Passageiro passageiro : passageiros) {
			result = result + "\nPassageiro: " + passageiros.get(i).get_nome_passageiro() + "\n Idade: " + passageiros.get(i).get_idade_passageiro() + "\n Lugar: " + passageiros.get(i).get_lugar_passageiro() + "\n\n";
			i++;
		}
		return result;
	}
}
