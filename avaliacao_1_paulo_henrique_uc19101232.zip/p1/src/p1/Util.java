package p1;

public class Util {
	//Essa fun��o � chamada na compra de passagem e recebe o dinherio mostra o troco se necess�rio
	//Ela retorna um booleano pra mostrar se houve um erro ou n�o
	static boolean compra_passagem(){
		try {
			float troco;
			float pagar = View.solicitar_float("PAGAMENTO", "O valor � R$ 100,00. Digite o valor pago:");
			Pagamento pagamento = new Pagamento(pagar);
			troco = pagamento.calcula_troco();
			if(troco == 0f) {
				View.exibir_mensagem("PAGAMENTO", "Pagamento realizado!");
			}else {
				View.exibir_mensagem("PAGAMENTO", "Pagamento realizado! Troco: " + troco);
			}	
			return true;
		} catch (IllegalArgumentException e) {
				View.exibir_exeption(e);
				return false;
		}
		
	}
}
