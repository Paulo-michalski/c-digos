package p1;

public class Pagamento {

//Atributos
	private float troco;
	private float pagamento;
	
	
//Construtor
	Pagamento(float pagamento){
		set_pagamento(pagamento);
	}
	
//Getter e setter
	public float get_pagamento() {
		return pagamento;
	}
	
	//Valida se o pagamento est� correto e retorna esta exeption
	public void set_pagamento(float pagamento) {
		if(pagamento >= 100f) {
		this.pagamento = pagamento;
		}else {
			throw new IllegalArgumentException("[PAGAMENTO]: O valor pago deve ser maior ou igual!");
		}
	}

//Metodos
	//Um metodo simples que retorna o troco do pagamento
	public float calcula_troco() {
		this.troco = this.pagamento - 100f;
		return troco;
	}
}
