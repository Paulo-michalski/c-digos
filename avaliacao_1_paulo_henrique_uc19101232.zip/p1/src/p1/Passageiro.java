package p1;

import java.io.CharConversionException;

public class Passageiro {

//Atributos
	private String nome_passageiro;
	private int idade_passageiro;
	private int lugar_passageiro;
	
//Construtor
	Passageiro(int idade_passageiro){
		set_idade_passageiro(idade_passageiro);
	}
	
//Getters e setter	
	public String get_nome_passageiro() {
		return nome_passageiro;
	}
	
	//O nome � validado pra ter certeza que vai ser colocado apenas letras e a string n�o esteja vazia
	public void set_nome_passageiro(String nome_passageiro) {
		int valida = 0;
		if(nome_passageiro.isBlank() == false) {
			for(int i = 0; i < nome_passageiro.length(); i++) {
				if(Character.isDigit(nome_passageiro.charAt(i))) {
					valida++;
				}
			}
		}else {
			valida++;
		}
		if(valida == 0) {
		this.nome_passageiro = nome_passageiro;
		}else {
			//Caso a valida��o encontre um erro ela retorna essa exeption
			throw new IllegalArgumentException("[PASSAGEIRO]: Digite o nome corretamente!");
		}
	}
	
	public int get_idade_passageiro() {
		return idade_passageiro;
	}
	
	//� validado pra que todos os passageiros sejam maiores de 18 e caso n�o sejam ela retorna uma exeption
	public void set_idade_passageiro(int idade_passageiro) {
		if(idade_passageiro >= 18) {
		this.idade_passageiro = idade_passageiro;
		}else {
			throw new IllegalArgumentException("[PASSAGEIRO]: Apenas maiores de 18 podem comprar passagens!");
		}
	}
	
	public int get_lugar_passageiro() {
		return lugar_passageiro;
	}
	
	public void set_lugar_passageiro(int lugar_passageiro) {
		this.lugar_passageiro = lugar_passageiro;
	}
}
