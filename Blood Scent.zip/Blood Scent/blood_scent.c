#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <windows.h>
#include <locale.h>

// Define para o teclado.
#define ACIMA 72
#define ABAIXO 80
#define DIREITA 77
#define ESQUERDA 75
#define ENTER 13

//Definhe para as cores.
#define vermelho "\x1b[31m"
#define verde "\x1b[32m"
#define amarelo "\x1b[33m"
#define azul "\x1b[34m"
#define rosa "\x1b[35m"
#define ciano "\x1b[36m"
#define reset "\x1b[0m"

//Struct para o personagem.
struct personagen {

	char nome[100];
	int nivel_besta;
	int fase;
	struct inventario *invent;
};

//Struct para o invent�rio.
struct inventario {

	int cartao;
	int sangue;
};

//Struct para as condi��es do personagem.
struct condicao {

	int sede;
	int cansado;
	int confuso;
	int ensandecido;
};

//Assinatura das fun��es e procedimentos.
void gotoxy(int x, int y);
int navegador(struct personagen persona, struct condicao cond);
void menu_jogo();
void continua(struct personagen persona, struct condicao cond);
void tutorial();
void tchau();
void epilogo(struct personagen persona, struct condicao cond);
void escolha_inicio(struct personagen persona, int aux, struct condicao cond);
void inventario(struct personagen persona);
void inicio_praia(struct personagen persona, struct condicao cond);
void caverna(struct personagen persona, int aux, struct condicao cond);
void praia_sangue(struct personagen persona, struct condicao cond);
void bebe_sangue(struct personagen persona, struct condicao cond);
void laboratorio(struct personagen persona, struct condicao cond);
void final_setorx(struct personagen persona, struct condicao cond);
void final_2(struct personagen persona, struct condicao cond);
void final_3(struct personagen persona, struct condicao cond);

int main() {

	//Arquivo do salvamento.
	FILE *arq_save;
	
	//Declara��o das structs.
	struct personagen persona;
	struct inventario invent;
	struct condicao cond;
	
	//A variavel opcao para o retorno da fun��o navegador.
	int opcao;
	
	//Inicializa��o
	persona.nivel_besta=0;
	persona.fase=1;
	
	//Aloca��o do relacionamento.
	persona.invent=(malloc(sizeof(struct inventario)));
	persona.invent->cartao=0;
	persona.invent->sangue=0;

	cond.cansado=0;
	cond.confuso=0;
	cond.ensandecido=0;
	cond.sede=1;

	//setlocale para a leitura dos acentos.
	setlocale(LC_ALL, "Portuguese");
	
	//Sistema de escolha do menu.
	do {
		
		//Chamada da fun�ao para saber a escolha do usu�rio.
		opcao = navegador(persona, cond);

		switch(opcao) {

			case 1:
				
				//Abertura e fechamento do aquivo para apagar dados salvos anteriormente.
				arq_save=fopen("save.txt","w");
				fclose(arq_save);
				
				//Chamada do procedimento para o inicio do jogo.
				epilogo(persona, cond);
				break;

			case 2:
				
				//Chamada para o procedimento para continuar o jogo do ultimo ponto salvo se exixtir.
				continua(persona, cond);
				break;

			case 3:
				
				//Chamada do procedimento que apenas mostra um aquivo de como jogar o jogo.
				tutorial();
				break;

			case 4:
				
				//Chamada do procedimento que mostra uma mensagem de adeus e fecha o programa.
				tchau();
				break;
		}

	} while(opcao != 4);
	
	free(persona.invent);

	return 0;
}

//Procedimento que implementa o gotoxy no programa para a possibilidade das setas funcionem.
void gotoxy(int x, int y) {
	COORD point;
	point.X = x;
	point.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), point);
}

//Fun��o que imprime as telas e as setas e possibilita o movimento as setas.
int navegador(struct personagen persona, struct condicao cond) {
	
	int tecla, x, y;
	
	//Inicializa��o de cada variavel para o posicionamento das setas.
	x=45;
	y=11;
	tecla=0;
	
	//Print das setas.
	system("cls");
	gotoxy(x,y);
	printf(vermelho "-->" reset);
	while(tecla != ENTER) {
		
		//Chmada dos procedimentos que imprimen na tela as op��es e prepara o recebimento das teclas do usu�rio.
		if(persona.fase==1) {

			menu_jogo();
			tecla=getch();
			system("cls");

		}

		if(persona.fase==2) {
			inicio_praia(persona, cond);
			tecla=getch();
			system("cls");
		}

		if(persona.fase==3) {
			praia_sangue(persona, cond);
			tecla=getch();
			system("cls");
		}

		if(persona.fase==4) {
			laboratorio(persona, cond);
			tecla=getch();
			system("cls");
		}


		//Sistema que controla o movimento da seta e o recebimento da tecla para acima.
		if(tecla==ACIMA) {

			if(y>11) {

				y=y-2;
				gotoxy(x,y);
				printf(vermelho "-->" reset);

			} else if(y==11) {

				if(persona.fase==3) {
					y=19;
				} else {
					y=17;
				}
				gotoxy(x,y);
				printf(vermelho "-->" reset);

			}
			
			//Sistema que controla o movimento da seta e o recebimento da tecla para baixo.
		} else if(tecla==ABAIXO) {
			
			//Na fase 3 existem uma op��o a mais do que nas outras fases, este if controla essa op��o a mais.
			if(persona.fase==3) {
				if(y<19) {

					y=y+2;
					gotoxy(x,y);
					printf(vermelho "-->" reset);

				} else if(y==19) {
					y=11;
					gotoxy(x,y);
					printf(vermelho "-->" reset);
				}

			} else {

				if(y<17) {

					y=y+2;
					gotoxy(x,y);
					printf(vermelho "-->" reset);

				} else if(y==17) {
					y=11;
					gotoxy(x,y);
					printf(vermelho "-->" reset);

				}
			}
			
			//Valida��o para apenas a entrada das teclas permitidas.
		} else if(tecla != ACIMA && tecla != ABAIXO) {

			gotoxy(x,y);
			printf(vermelho "-->" reset);

		}
	}
	
	//Retorno da fun��o baseado na posi��o da seta para a escolha da op��o.
	system("cls");
	if(y == 11) {
		return 1;
	} else if (y == 13) {
		return 2;
	} else if(y == 15) {
		return 3;
	} else if(y == 17) {
		return 4;
	} else if(y == 19) {
		return 5;
	}

}

//Procedimento que mostra o menu do jogo e suas op�oes.
void menu_jogo() {

	FILE *arq_menu;
	int y=2;
	char menus[100];

	arq_menu=fopen("menu.txt","r");

	while(fgets(menus,100, arq_menu)) {
		gotoxy(10,y);
		printf(vermelho "%s" reset, menus);
		y++;
	}

	gotoxy(50,11);
	printf(rosa "Novo jogo\n" reset);
	gotoxy(50,13);
	printf(verde "Continuar\n" reset);
	gotoxy(50,15);
	printf("Como Jogar\n");
	gotoxy(50,17);
	printf(azul "Sair\n" reset);

	fclose(arq_menu);
}

//Procedimento que chama o come�o do jogo.
void epilogo(struct personagen persona, struct condicao cond) {

	FILE *arq_epl, *arq_save;
	int y=2, j=0, valida=0, aux=0;
	char epl[100];

	system("cls");
	
	//Abertura do arquivo.
	arq_epl=fopen("epilogo.txt","r");
	arq_save=fopen("save.txt","w");

	//Impress�o do arquivo.
	while(fgets(epl, 100, arq_epl)) {

		gotoxy(10,y);
		if(y==2) {

			printf(vermelho "%s" reset, epl);
		} else {
			gotoxy(8,y);
			printf(rosa "%s" reset, epl);
		}
		y++;
	}

	sleep(2);
	
	//Entrada e valida��o para o nome colocado pelo usu�rio.
	do {
		if(valida!=0) {
			system("cls");
		}
		gotoxy(50,8);
		printf("Digite o seu nome:\n");
		fflush(stdin);
		gotoxy(50,10);
		gets(persona.nome);

		valida=0;

		//Valida��o.
		if(strlen(persona.nome) > 0) {

			for(j=0; j<strlen(persona.nome); j++) {
				if(isalpha(persona.nome[j])==0 || persona.nome[0]==' ') {
					if(persona.nome[j]!=' ') {
						valida=1;
						break;
					}
				}
			}
		}
		if(persona.nome[0] == '\0') {
			valida=1;
		}
	} while(valida != 0);

	gotoxy(0,15);
	printf("Pressione qualquer tecla para continuar...\n");
	fflush(stdin);
	getchar();

	persona.fase=2;
	
	//Salvamento em um arquivo do nome e invent�rio para possibilida da continua��o.
	fprintf(arq_save, "%s\n", persona.nome);
	fprintf(arq_save,"%i\n", persona.invent->sangue);
	fprintf(arq_save,"%i\n", persona.invent->cartao);

	fclose(arq_epl);
	fclose(arq_save);
	
	//Chamada do procedimento que possibilita a escolha do usu�rio.
	escolha_inicio(persona, aux, cond);

}

//Procedimento que possibilita a escolha do usu�rio durante o jogo
void escolha_inicio(struct personagen persona, int aux, struct condicao cond) {

	int opcao=0;
	
	//Switch que possibilita a escolha besado no retorno da fun��o navegador.
	if(persona.fase==2) { 
		do {

			opcao=navegador(persona, cond);

			switch(opcao) {

				case 1:

					cond.confuso=1;
					persona.invent->cartao=1;
					caverna(persona, aux, cond);
					aux++;
					break;

				case 2:
					cond.confuso=1;
					persona.fase=3;
					escolha_inicio(persona, aux, cond);
					break;

				case 3:
					inventario(persona);
					persona.fase=2;
					break;

				case 4:
					main();
					break;
			}

		} while(opcao != 4);

	}else if(persona.fase==3) {

		do {

			opcao=navegador(persona, cond);
			cond.cansado=1;

			switch(opcao) {

				case 1:

					if(persona.invent->cartao==0) {

						gotoxy(35,5);
						printf(verde"Voc� n�o possui o cart�o de acesso\n"reset);
						gotoxy(0,20);
						printf("Pressione qualquer tecla para continuar...\n");
						fflush(stdin);
						getchar();

					} else if(persona.invent->cartao==1) {

						persona.fase=4;
						persona.invent->cartao=0;
						escolha_inicio(persona, aux, cond);

					}

					break;

				case 2:

					bebe_sangue(persona, cond);
					if(cond.sede==1) {
						persona.nivel_besta=2;
						persona.invent->sangue=1;
					}
					cond.sede=0;
					break;

				case 3:
					persona.fase=2;
					escolha_inicio(persona, aux, cond);
					break;

				case 4:
					inventario(persona);
					break;

				case 5:
					main();
					break;
			}

		} while(opcao != 5);

	}else if(persona.fase==4) {

		do {
			
			opcao=navegador(persona, cond);

			switch(opcao) {

				case 1:

					final_setorx(persona, cond);
					main();
					break;

				case 2:

					if(persona.nivel_besta==2) {

						final_2(persona, cond);

					} else {

						final_3(persona, cond);

					}

					main();
					break;

				case 3:
					inventario(persona);
					break;

				case 4:
					main();
					break;
			}

		} while(opcao != 4);

	}

}

//Procedimento que imprime a hist�ria e as op��es da segunda parte do jogo.
void inicio_praia(struct personagen persona, struct condicao cond) {

	FILE *arq_inicio, *arq_save;
	char inicio[100];
	int y=2;

	arq_inicio=fopen("inicio.txt","r");
	arq_save=fopen("save.txt","w");
	
	//Salvamento dos dados do jogador no arquivo.
	fprintf(arq_save, "%s\n", persona.nome);
	fprintf(arq_save,"%i\n", persona.invent->sangue);
	fprintf(arq_save,"%i\n", persona.invent->cartao);
	fprintf(arq_save,"%i\n", cond.cansado);
	fprintf(arq_save,"%i\n", cond.confuso);
	fprintf(arq_save,"%i\n", cond.sede);
	fprintf(arq_save,"%i\n", cond.ensandecido);
	fprintf(arq_save,"%i\n", persona.fase);

	if(cond.confuso==0) {

		while(fgets(inicio,100, arq_inicio)) {
			gotoxy(18,y);
			printf("%s", inicio);
			y++;
		}

	} else if(cond.confuso==1) {
		gotoxy(18,y);
		printf("A praia continua a mesma.\n");
	}

	gotoxy(50,11);
	printf("Explorar a caverna\n");
	gotoxy(50,13);
	printf("Ir para o lado esquerdo\n");
	gotoxy(50,15);
	printf("Invent�rio\n");
	gotoxy(50,17);
	printf(azul "Sair\n" reset);
	
	//As condi��es do personagem.
	gotoxy(2,0);
	printf("CONDI��O: ");

	if(cond.cansado==1) {
		printf(" |CANSADO| ");
	}
	if(cond.confuso==1) {
		printf(" |CONFUSO| ");
	}
	if(cond.sede==1) {
		printf(" |SEDE| ");
	}
	if(cond.ensandecido==1) {
		printf(vermelho" |ENSANDECIDO| "reset);
	}


	fclose(arq_inicio);
	fclose(arq_save);

}

//Procedimento que imprime a historia da caverna e adiciona um intem no invet�rio.
void caverna(struct personagen persona, int aux, struct condicao cond) {

	FILE *arq_cave;
	char cave[100];
	int y=2;

	system("cls");

	arq_cave=fopen("caverna.txt", "r");

	if(aux==0) {

		while(fgets(cave, 100, arq_cave)) {
			gotoxy(18,y);
			printf("%s", cave);
			y++;
		}

		gotoxy(18,10);
		printf(azul"Voc� colocou o cart�o estranho em seu invent�rio!\n"reset);

	} else {

		gotoxy(18,y);
		printf("Nada na caverna te chama aten��o...\n");
	}

	gotoxy(2,0);
	printf("CONDI��O: ");

	if(cond.cansado==1) {
		printf(" |CANSADO| ");
	}
	if(cond.confuso==1) {
		printf(" |CONFUSO| ");
	}
	if(cond.sede==1) {
		printf(" |SEDE| ");
	}
	if(cond.ensandecido==1) {
		printf(vermelho" |ENSANDECIDO| "reset);
	}

	gotoxy(0,20);
	printf("Pressione qualquer tecla para continuar...\n");
	fflush(stdin);
	getchar();

	fclose(arq_cave);

}

//Procedimento da 3 parte do jogo
void praia_sangue(struct personagen persona, struct condicao cond) {

	FILE *arq_sangue, *arq_save;
	char praia[140];
	int y=1;

	arq_sangue=fopen("praia_s.txt", "r");
	arq_save=fopen("save.txt","w");

	fprintf(arq_save, "%s\n", persona.nome);
	fprintf(arq_save,"%i\n", persona.invent->sangue);
	fprintf(arq_save,"%i\n", persona.invent->cartao);
	fprintf(arq_save,"%i\n", cond.cansado);
	fprintf(arq_save,"%i\n", cond.confuso);
	fprintf(arq_save,"%i\n", cond.sede);
	fprintf(arq_save,"%i\n", cond.ensandecido);
	fprintf(arq_save,"%i\n", persona.fase);

	if(cond.cansado==0) {

		while(fgets(praia,140, arq_sangue)) {
			gotoxy(18,y);
			printf("%s", praia);
			y++;
		}

		y--;
		persona.nivel_besta++;
		gotoxy(18,y);
		printf(vermelho"Algo dentro de voc� desperta...\n"reset);


	} else if(cond.cansado=1) {

		gotoxy(25,5);
		printf(" Corpos despedasados te observam na areia vermelha...\n");

	}

	gotoxy(50,11);
	printf("Interagir com a porta\n");
	gotoxy(50,13);
	printf("Beber sangue\n");
	gotoxy(50,15);
	printf("Voltar a praia\n");
	gotoxy(50,17);
	printf("Invent�rio\n");
	gotoxy(50,19);
	printf(azul "Sair\n" reset);

	gotoxy(2,0);
	printf("CONDI��O: ");

	if(cond.cansado==1) {
		printf(" |CANSADO| ");
	}
	if(cond.confuso==1) {
		printf(" |CONFUSO| ");
	}
	if(cond.sede==1) {
		printf(" |SEDE| ");
	}
	if(cond.ensandecido==1) {
		printf(vermelho" |ENSANDECIDO| "reset);
	}

	fclose(arq_sangue);
	fclose(arq_save);

}

//Procedimento que aumenta 1 nivel de besta e muda 1 intem do invent�rio.
void bebe_sangue(struct personagen persona, struct condicao cond) {

	int y=2;

	if(cond.sede==1) {
		gotoxy(18,y);
		printf("Voc� vai proximo a um corpo e bebe o sangue at� saciar a sua sede...\n");
		gotoxy(18,4);
		printf(vermelho"Algo dentro de voc� observa...\n"reset);
	} else if(cond.sede==0) {
		gotoxy(18,y);
		printf("Voc� n�o tem mais sede...");
	}

	gotoxy(2,0);
	printf("CONDI��O: ");

	if(cond.cansado==1) {
		printf(" |CANSADO| ");
	}
	if(cond.confuso==1) {
		printf(" |CONFUSO| ");
	}
	if(cond.sede==1) {
		printf(" |SEDE| ");
	}
	if(cond.ensandecido==1) {
		printf(vermelho" |ENSANDECIDO| "reset);
	}

	gotoxy(0,20);
	printf("Pressione qualquer tecla para continuar...\n");
	fflush(stdin);
	getchar();

}

//Procedimento para a parte 4 do jogo.
void laboratorio(struct personagen persona, struct condicao cond) {

	FILE *arq_lab;
	char lab[100];
	int y=2;

	arq_lab=fopen("laboratorio.txt","r");

	while(fgets(lab,100, arq_lab)) {
		gotoxy(18,y);
		printf("%s", lab);
		y++;
	}

	gotoxy(50,11);
	printf("Ir para o setor X\n");
	gotoxy(50,13);
	printf("Ir para o setor A\n");
	gotoxy(50,15);
	printf("Invent�rio\n");
	gotoxy(50,17);
	printf(azul "Sair\n" reset);

	gotoxy(2,0);
	printf("CONDI��O: ");

	if(cond.cansado==1) {
		printf(" |CANSADO| ");
	}
	if(cond.confuso==1) {
		printf(" |CONFUSO| ");
	}
	if(cond.sede==1) {
		printf(" |SEDE| ");
	}
	if(cond.ensandecido==1) {
		printf(vermelho" |ENSANDECIDO| "reset);
	}

	fclose(arq_lab);

}

//Procedimento que mostra um dos finais do jogo(final 1).
void final_setorx(struct personagen persona, struct condicao cond) {

	FILE *arq_setorx;
	char setorx[100];
	int y=2;
	cond.confuso=0;

	arq_setorx=fopen("final_setorx.txt","r");

	while(fgets(setorx,100, arq_setorx)) {
		gotoxy(18,y);
		printf("%s", setorx);
		y++;
	}

	gotoxy(34,8);
	printf("%s", persona.nome);

	gotoxy(2,0);
	printf("CONDI��O: ");

	if(cond.cansado==1) {
		printf(" |CANSADO| ");
	}
	if(cond.confuso==1) {
		printf(" |CONFUSO| ");
	}
	if(cond.sede==1) {
		printf(" |SEDE| ");
	}
	if(cond.ensandecido==1) {
		printf(vermelho" |ENSANDECIDO| "reset);
	}

	gotoxy(0,20);
	printf(rosa"FIM 1/3\n"reset);
	fflush(stdin);
	getchar();

	fclose(arq_setorx);

}

//Procedimento que mostra um dos finais do jogo(final 2).
void final_2(struct personagen persona, struct condicao cond) {

	FILE *arq_final2;
	char final2[100];
	int y=2;
	cond.confuso=0;
	cond.cansado=0;
	cond.ensandecido=1;

	arq_final2=fopen("final_2.txt","r");

	while(fgets(final2,100, arq_final2)) {
		gotoxy(18,y);
		printf("%s", final2);
		y++;
	}

	gotoxy(2,0);
	printf("CONDI��O: ");

	if(cond.cansado==1) {
		printf(" |CANSADO| ");
	}
	if(cond.confuso==1) {
		printf(" |CONFUSO| ");
	}
	if(cond.sede==1) {
		printf(" |SEDE| ");
	}
	if(cond.ensandecido==1) {
		printf(vermelho" |ENSANDECIDO| "reset);
	}

	gotoxy(0,20);
	printf(rosa"FIM 2/3\n"reset);
	fflush(stdin);
	getchar();

	fclose(arq_final2);

}

//Procedimento que mostra um dos finais do jogo(final 3).
void final_3(struct personagen persona, struct condicao cond) {

	FILE *arq_final3;
	char final3[100];
	int y=2;
	cond.confuso=0;
	cond.sede=0;

	arq_final3=fopen("final_3.txt","r");

	while(fgets(final3,100, arq_final3)) {
		gotoxy(18,y);
		printf("%s", final3);
		y++;
	}

	gotoxy(2,0);
	printf("CONDI��O: ");

	if(cond.cansado==1) {
		printf(" |CANSADO| ");
	}
	if(cond.confuso==1) {
		printf(" |CONFUSO| ");
	}
	if(cond.sede==1) {
		printf(" |SEDE| ");
	}
	if(cond.ensandecido==1) {
		printf(vermelho" |ENSANDECIDO| "reset);
	}

	gotoxy(0,20);
	printf(rosa"FIM 3/3\n"reset);
	fflush(stdin);
	getchar();

	fclose(arq_final3);


}

//Procedimento que mostra os itens no iventario.
void inventario(struct personagen persona) {

	int y=4;

	system("cls");

	gotoxy(25,2);
	printf(" |INVENT�RIO| \n");
	if(persona.invent->cartao==1) {
		gotoxy(25,y);
		printf("Cartao estranho\n");
		y+=2;
	}

	if(persona.invent->sangue==1) {
		gotoxy(25,y);
		printf("Roupas ensanguentadas\n");
		y+=2;
	} else {
		gotoxy(25,y);
		printf("Roupas sujas\n");
		y+=2;
	}

	gotoxy(0,15);
	printf("Pressione qualquer tecla para voltar...\n");
	fflush(stdin);
	getchar();
}

//Procedimento que mostra os controles do jogo
void tutorial() {

	FILE *arq_tutorial;
	char tut[100];
	int y=2;

	arq_tutorial=fopen("tutorial.txt","r");

	while(fgets(tut,100, arq_tutorial)) {
		gotoxy(35,y);
		printf(verde "%s" reset, tut);
		y++;
	}

	gotoxy(0,15);
	printf("Pressione qualquer tecla para voltar ao menu...\n");
	fflush(stdin);
	getchar();


	fclose(arq_tutorial);

}

//Procedimento que l� o arquivo e possibilita a continua��o do jogo do utimo ponto salvo.
void continua(struct personagen persona, struct condicao cond) {

	FILE *arq_save;
	char nome[100];
	int aux;

	arq_save=fopen("save.txt","r");

	if(fgets(nome, 100, arq_save)==NULL) {

		gotoxy(35,2);
		printf("Nenhum arquivio foi salvo anteriormente.\n");
		getch();
		main();
		
	}else{
	
	strcpy(persona.nome,nome);
	fscanf(arq_save," %i ",&persona.invent->sangue);
	fscanf(arq_save," %i ",&persona.invent->cartao);
	fscanf(arq_save," %i ",&cond.cansado);
	fscanf(arq_save," %i ",&cond.confuso);
	fscanf(arq_save," %i ",&cond.sede);
	fscanf(arq_save," %i ",&cond.ensandecido);
	fscanf(arq_save," %i ",&persona.fase);
	printf("%i", persona.fase);

	if(persona.invent->cartao==1) {

		aux=1;
	} else {
		aux=0;
	}
	escolha_inicio(persona, aux, cond);
	
	fclose(arq_save);
	}
}

//Procedimento que mostra uma mensagem de adeus e fecha o programa.
void tchau() {

	FILE *arq_tchau;
	char tchau[100];
	int y=2;

	system("cls");
	arq_tchau=fopen("tchau.txt","r");

	while(fgets(tchau,100, arq_tchau)) {
		gotoxy(35,y);
		printf(rosa "%s" reset, tchau);
		y++;
	}

	fclose(arq_tchau);

	exit(1);
}
