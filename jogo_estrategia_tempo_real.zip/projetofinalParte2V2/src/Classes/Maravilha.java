package Classes;

import tela.Principal;

public class Maravilha {
	
	//Atributos
	private Principal principal;
	private Vila vila;
	private int tijolo;
	
	//Construtor
	public Maravilha(Vila vila, Principal principal){
		this.vila = vila;
		this.principal = principal;
		this.tijolo = 0;
		this.principal.habilitarMaravilha();
		this.principal.mostrarMaravilha(this.tijolo);
	}
	
	
	//Motodos
	public void produzirTijolo(){
		try {
			if(this.tijolo < 100000){
				Thread.sleep(1000);
				this.tijolo += 1;
				this.principal.mostrarMaravilha(this.tijolo);
			}else{
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	// Esse comando � usado quando a vila � atacada
	public void retirarTijolo(int retirar){
		this.tijolo -= retirar;
		this.principal.mostrarMaravilha(this.tijolo);
	}
		
	public int getTijolo(){
		return this.tijolo;
	}
}
