package Classes;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.List;

import tela.Principal;

public class ClienteTCP extends Thread implements Serializable {
	private static final long serialVersionUID = 1L;
	// Atributos
	private Principal principal;
	private boolean ouvindo;
	private ClienteTCP clienteRecebe;
	private Jogador jogador;
	private List<Jogador> jogadores;

	// Atributos conexao
	private Socket conexao;
	private ObjectOutputStream saida;

	// Construtores
	public ClienteTCP(Principal principal) {
		this.principal = principal;
		this.ouvindo = true;
	}

	public ClienteTCP(Socket conexao, Principal principal) {
		this.conexao = conexao;
		this.principal = principal;
		this.ouvindo = true;

	}

	// Metodos
	public void run() {
		String mensagem;
		ObjectInputStream entrada = null;
		try {
			entrada = new ObjectInputStream(this.conexao.getInputStream());
			while (this.ouvindo) {
				mensagem = (String) entrada.readObject();
				System.out.println(mensagem + " <-- ClienteTCP");

				switch (mensagem) {
				case "CMD||RECEBERJOGADORES":
					List<Jogador> listaRecebida = (List<Jogador>) entrada.readObject();
					this.jogadores = listaRecebida;
					this.principal.limparJogadores();
					this.principal.limparInimigos();
					for (Jogador jogador : jogadores) {
						this.principal.adicionarJogador(jogador.getNomeJogador(), jogador.getCivilizacao(),
								jogador.getIp(), "aguardando iniciar... " + jogador.getId());
					}
					mostrarInimigos();
					break;
				case "CMD||INICIARJOGO":
					principal.comandoIniciarJogo();
					break;

				case "CMD||TERMINAR":
					String nomeVencedor = (String) entrada.readObject();
					this.principal.mostrarMensagemErro("O JOGO ACABOU", "O JOGADOR: " + nomeVencedor + " venceu!");
					encerrarJogo();
					break;

				case "CMD||RECEBERATAQUE":
					String ataque = (String) entrada.readObject();
					String nomeJogador = (String) entrada.readObject();

					// acessar a principal, templo, ataque
					if (this.principal.getJogadorPrincipal().getNomeJogador().equals(nomeJogador)) {
						// recebe o ataque
						this.principal.comandoVilaReceberAtaque(ataque);
					}
					break;
				case "CMD||ENCERRAR":
					this.principal.desconectarCliente();
					this.principal.comandoEncerrarJogo();
					this.principal.mostrarMensagemErro("Encerrar", "Jogo Encerrado");
					System.exit(0);
					break;
				case "CMD||VITORIA":
					String jogadorVencedor = (String) entrada.readObject();
					this.principal.mostrarMensagemErro("Venceu", jogadorVencedor + " Venceu o jogo");
					this.principal.desconectarCliente();
					this.principal.comandoEncerrarJogo();
					System.exit(0);
					break;

				default:
					this.principal.adicionarMensagem(mensagem);
				}
			}
			entrada.close();
		} catch (IOException | ClassNotFoundException e) {

		}
	}

	// Metodos conexao
	public boolean conectar(String host, Jogador jogador) {
		try {
			this.conexao = new Socket(host, 12345);
			this.saida = new ObjectOutputStream(conexao.getOutputStream());
			this.jogador = jogador;

			// mandar o comando
			this.saida.writeObject(jogador.getNomeJogador() + " - " + jogador.getCivilizacao());
			this.saida.writeObject(jogador);
			this.saida.writeObject("CMD||CONECT");
			this.clienteRecebe = new ClienteTCP(conexao, this.principal);
			this.clienteRecebe.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public void desconectar() {
		try {
			this.saida.writeObject("CMD||DESCONECTAR");
			this.setOuvindo(false);
			this.saida.close();
			this.conexao.close();
		} catch (IOException e) {

		}
	}

	public void enviarMensagem(String mensagem) {
		try {
			this.saida.writeObject(mensagem);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void iniciarJogo() {
		try {
			this.saida.writeObject("CMD||INICIARJOGO");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void vencerJogo() {
		try {
			this.saida.writeObject("CMD||VENCEU");
			System.out.println(this.jogador.getNomeJogador() + " <-------------- venceu o jogo");
			this.saida.writeObject(this.jogador.getNomeJogador());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void encerrarJogo() {
		try {
			this.saida.writeObject("CMD||ENCERRAR");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public boolean isOuvindo() {
		return ouvindo;
	}

	public void setOuvindo(boolean ouvindo) {
		this.ouvindo = ouvindo;
	}

	public void mostrarInimigos() {
		this.principal.limparInimigos();
		for (Jogador jogador : jogadores) {
			if (!this.principal.getJogadorPrincipal().getNomeJogador().equals(jogador.getNomeJogador())) {
				this.principal.adicionarInimigo(jogador);
			}
		}
	}

	public void ataque(String ataque, String jogador) {

		try {
			this.saida.writeObject("CMD||ATTACK");
			this.saida.writeObject(ataque);
			this.saida.writeObject(jogador);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
