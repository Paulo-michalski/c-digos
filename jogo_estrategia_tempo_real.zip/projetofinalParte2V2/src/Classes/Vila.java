package Classes;

import java.util.ArrayList;
import java.util.List;
import tela.Principal;

public class Vila {
	// Atributos
	private Principal principal;
	private Prefeitura prefeitura;
	private List<Aldeao> aldeoes = new ArrayList<Aldeao>();
	private List<Fazenda> fazendas = new ArrayList<Fazenda>();
	private List<Mina> minas = new ArrayList<Mina>();
	private Templo templo;
	private Maravilha maravilha;
	private boolean protecaoNuvem;
	private boolean protecaoMorte;
	private boolean protecaoChuva;
	private boolean venceu;

	// Construtores
	public Vila(Principal principal) {
		this.principal = principal;
		this.prefeitura = new Prefeitura(this.principal, this);
		this.prefeitura.start();
		this.maravilha = new Maravilha(this, this.principal);
		this.protecaoNuvem = false;
		this.protecaoMorte = false;
		this.protecaoChuva = false;
		this.venceu = false;
		iniciarVilla();
	}

	// Metodos

	/****************** lista aldeoes *************************/
	public int gerarIdAldeao() {
		return this.aldeoes.size();
	}

	public void addAldeoes(Aldeao aldeao) {
		this.aldeoes.add(aldeao);
	}

	public Aldeao getAldeao(int id) {
		return this.aldeoes.get(id);
	}

	public List<Aldeao> getListaAldeos() {
		return this.aldeoes;
	}

	/****************** lista fazendas *************************/
	public void addFazenda(Fazenda fazenda) {
		this.fazendas.add(fazenda);
	}

	public Fazenda getFazenda(int id) {
		return this.fazendas.get(id);
	}

	public int gerarIdFazenda() {
		return this.fazendas.size();
	}

	public List<Fazenda> getListaFazendas() {
		return this.fazendas;
	}

	/****************** lista Mina *************************/
	public void addMina(Mina mina) {
		this.minas.add(mina);
	}

	public Mina getMina(int id) {
		return this.minas.get(id);
	}

	public int gerarIdMina() {
		return this.minas.size();
	}

	public List<Mina> getListaMinas() {
		return this.minas;
	}

	/****************** templo *************************/
	public void setTemplo(Templo t) {
		this.templo = t;
	}

	public Templo getTemplo() {
		return this.templo;
	}

	/****************** maravilha *************************/
	public void setMaravilha(Maravilha m) {
		this.maravilha = m;
	}

	public Maravilha getMaravilha() {
		return this.maravilha;
	}

	/****************** prefeitura *************************/
	public Prefeitura getPrefeitura() {
		return this.prefeitura;
	}

	//Verifica o pre�o das cois e remove se puder paga, esse metodo � usado em todo c�digo
	public boolean verificaEPaga(int comida, int ouro, int oferenda) {
		if (this.prefeitura.getComida() >= comida && this.prefeitura.getOuro() >= ouro
				&& this.prefeitura.getOferenda() >= oferenda) {
			this.prefeitura.retirarComida(comida);
			this.prefeitura.retirarOuro(ouro);
			this.prefeitura.retirarOferenda(oferenda);
			this.principal.mostrarComida(this.prefeitura.getComida());
			this.principal.mostrarOuro(this.prefeitura.getOuro());
			this.principal.mostrarOferendaFe(this.prefeitura.getOferenda());
			return true;
		}
		return false;
	}

	//Fica predefinido o que o jogador tem no in�cio do jogo
	private void iniciarVilla() {

		this.principal.mostrarComida(this.getPrefeitura().getComida());
		this.principal.mostrarOuro(this.getPrefeitura().getOuro());

		// 5 aldeoes
		for (int i = 0; i < 5; i++) {
			Aldeao aldeao = new Aldeao(this, i, this.principal);
			this.addAldeoes(aldeao);
			aldeao.start();
			this.principal.adicionarAldeao(String.valueOf(i + 1), "fazendo nada");
			this.principal.mostrarAldeao(i + 1, "continua fazendo nada");
		}
		// 1 fazenda
		Fazenda fazenda = new Fazenda(this, gerarIdFazenda(), this.principal);
		this.addFazenda(fazenda);
		this.principal.adicionarFazenda("1", "aldeoesA");
		this.principal.mostrarFazenda(1, fazenda.stringListaId());

		// 1 mina de ouro
		Mina mina = new Mina(this, gerarIdMina(), this.principal);
		this.addMina(mina);
		this.principal.adicionarMinaOuro("1", "aldeoesA");
		this.principal.mostrarMinaOuro(1, mina.stringListaId());

	}

	// ----------------------Ataques-------------------------------\\
	
	//Filtra qual ataque o jogador recebeu
	public void receberAtaque(String ataque) {
		switch (ataque) {
		case "Nuvem de gafanhotos":
			if (this.protecaoNuvem == false) {
				destruirFazendas();
			}
			break;

		case "Morte dos primog�nitos":
			if (this.protecaoMorte == false) {
				// colocar para receber o ataque
				assassinarAldeaos();
			}
			break;

		case "Chuva de pedras":
			if (this.protecaoChuva == false) {
				// colocar para receber o ataque
				destruirFazendas();
				destruirMinas();
				destruirMaravilha();
				assassinarAldeaos();
			}
			break;

		}
	}

	// ----------------> receber ataques
	
	//Os efeitos dos ataque
	private void destruirFazendas() {
		int fazendasFuncionais = 0;
		int fazendasDestruir = 0;
		int destruiu = 0;

		for (Fazenda fazenda : fazendas) {
			if (fazenda.isFuncional()) {
				fazendasFuncionais++;
			}
		}

		if (fazendasFuncionais > 1) {
			fazendasDestruir = fazendasFuncionais / 2;
		} else {
			fazendasDestruir = 1;
		}

		for (Fazenda fazenda : fazendas) {
			if (destruiu < fazendasDestruir) {
				if (fazenda.isFuncional()) {
					fazenda.matarFazenda();
					this.principal.mostrarFazenda(fazenda.getIdFazenda() + 1, fazenda.stringListaId());
					destruiu++;
				}
			} else {
				return;
			}
		}
	}

	private void destruirMinas() {
		int minasFuncionais = 0;
		int minasDestruir = 0;
		int destruiu = 0;

		for (Mina mina : this.minas) {
			if (mina.isFuncional()) {
				minasFuncionais++;
			}
		}

		if (minasFuncionais > 1) {
			minasDestruir = minasFuncionais / 2;
		} else {
			minasDestruir = 1;
		}

		for (Mina mina : this.minas) {
			if (destruiu < minasDestruir) {
				if (mina.isFuncional()) {
					mina.matarMina();
					this.principal.mostrarMinaOuro(mina.getIdMina() + 1, mina.stringListaId());
					destruiu++;
				}
			} else {
				return;
			}
		}
	}

	public void assassinarAldeaos() {
		int aldeoesVivos = 0;
		int aldeoesMatar = 0;
		int assassinou = 0;
		for (Aldeao aldeao : aldeoes) {
			if (aldeao.isVivo()) {
				aldeoesVivos++;
			}
		}

		if (aldeoesVivos > 1) {
			aldeoesMatar = aldeoesVivos / 2;
		} else {
			aldeoesMatar = 1;
		}

		for (Aldeao aldeao : aldeoes) {
			if (assassinou < aldeoesMatar) {
				if (aldeao.isVivo()) {
					aldeao.setFuncaoAtual(AcaoAldeao.ASSASSINAR);
					assassinou++;
				}
			} else {
				return;
			}
		}
	}

	public void destruirMaravilha() {
		int tijolos = this.maravilha.getTijolo();
		int retirar = 0;

		if (tijolos != 0) {
			if (tijolos == 1) {
				retirar = tijolos;
			} else {
				retirar = tijolos / 2;
			}
			this.maravilha.retirarTijolo(retirar);
		}

	}

	//Ativa as prote��es que o jogador tem e o torna imune
	public void ativarProtecaoNuvem() {
		this.protecaoNuvem = true;
	}

	public void ativarProtecaoMorte() {
		this.protecaoMorte = true;
	}

	public void ativarProtecaoChuva() {
		this.protecaoChuva = true;
	}

	//Modifica a situa��o de vit�ria do jogador
	public void setVenceu(boolean vencer) {
		this.venceu = vencer;
	}

	public boolean getVenceu() {
		return this.venceu;
	}

}
