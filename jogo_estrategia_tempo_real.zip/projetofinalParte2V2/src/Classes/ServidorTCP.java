package Classes;

import java.net.Socket;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import tela.Principal;
import tela.enumerador.SituacaoInicio;

public class ServidorTCP extends Thread {
	// Atributos
	private Socket conexao;
	private List<ObjectOutputStream> saidas;
	private SituacaoInicio situacao;
	private boolean vivo;
	private Principal principal;
	// lista de jogadores
	private List<Jogador> jogadores;
	private int idJogadorHost;
	private ServerSocket servidorPrincipal;

	// Construtor
	public ServidorTCP(Socket conexao, List<ObjectOutputStream> saidas, Principal principal, List<Jogador> jogadores) {
		System.out.println("Cliente conectado: " + conexao.getInetAddress().getHostAddress());
		this.conexao = conexao;
		this.saidas = saidas;
		this.vivo = true;
		this.situacao = SituacaoInicio.INICIAL_CRIAR;
		this.principal = principal;
		this.jogadores = jogadores;
	}

	public ServidorTCP(Principal principal) {
		this.vivo = true;
		this.situacao = SituacaoInicio.INICIAL_CRIAR;
		this.principal = principal;
		this.jogadores = new ArrayList<Jogador>();
	}

	// Metodos
	public void run() {

		while (this.vivo) {

			if (!this.jogadores.isEmpty()) {
				mostrarJogadores();
			}

			switch (this.situacao) {
				
			case INICIAL_CONECTAR:
				levantarServidor();
				break;
				
			case CONECTADO:
				conectado();
				break;
				
			case SERVIDOR_PARAR:
				System.out.println("entrou no servidor parar");
				this.vivo = false;
				
			default:
				break;
			}
		}
	}

	private void conectado() {
		System.out.println("entrou no na funcao conectado");
		DateFormat horaMinuto = new SimpleDateFormat("HH:mm");
		try {
			ObjectInputStream entrada = new ObjectInputStream(this.conexao.getInputStream());
			ObjectOutputStream saida = new ObjectOutputStream(this.conexao.getOutputStream());

			synchronized (saida) {
				this.saidas.add(saida);
			}

			String mensagem = (String) entrada.readObject();
			super.setName(mensagem);
			Jogador host = (Jogador) entrada.readObject();

			try {
				while (!(mensagem = (String) entrada.readObject()).equals("CMD||DESCONECTAR")) {
					System.out.println("entrou no while do servidor");

					switch (mensagem) {

					case "CMD||CONECT":
						System.out.println("jogador entrando no servido: " + host.getNomeJogador());
						if (this.jogadores == null) {
							host.setId(0);
						} else {
							host.setId(this.jogadores.size());
						}
						synchronized (this.jogadores) {
							this.jogadores.add(host);
						}
						synchronized (this.saidas) {
							for (ObjectOutputStream enviarLista : this.saidas) {
								enviarLista.writeObject("CMD||RECEBERJOGADORES");
								enviarLista.writeObject(jogadores);
							}
						}
						mostrarJogadores();
						this.situacao = SituacaoInicio.CONECTADO;
						break;

					case "CMD||INICIARJOGO":
						System.out.println("entrou no iniciar jogo servidor");
						System.out.println("tamanho da saida -->" + this.saidas.size());
						synchronized (this.saidas) {
							for (ObjectOutputStream enviarMsg : this.saidas) {
								enviarMsg.writeObject("CMD||INICIARJOGO");
							}
						}
						break;

					case "CMD||VENCEU":
						String jogadorVencedor = (String) entrada.readObject();
						synchronized (this.saidas) {
							for (ObjectOutputStream enviarMsg : this.saidas) {
								enviarMsg.writeObject("CMD||VITORIA");
								enviarMsg.writeObject(jogadorVencedor);
							}
						}
						break;

					case "CMD||ATTACK":
						String ataqueRecebido = (String) entrada.readObject();
						String jogadorRecebido = (String) entrada.readObject();
						synchronized (this.saidas) {
							for (ObjectOutputStream enviarAtk : this.saidas) {
								enviarAtk.writeObject("CMD||RECEBERATAQUE");
								enviarAtk.writeObject(ataqueRecebido);
								enviarAtk.writeObject(jogadorRecebido);
							}
						}
						break;

					case "CMD||ENCERRAR":
						synchronized (this.saidas) {
							for (ObjectOutputStream enviarMsg : this.saidas) {
								enviarMsg.writeObject("CMD||ENCERRAR");
							}
						}
						break;

					default:
						// Parte de mandar a mensagem
						synchronized (this.saidas) {
							String msg = super.getName() + "(" + horaMinuto.format(new Date()) + "): " + mensagem;
							for (ObjectOutputStream enviarMsg : this.saidas) {
								enviarMsg.writeObject(msg);
							}
						}
					}
				} // <--------- while acaba aqui

			} catch (SocketException e) {

			}

			// Mandar
			synchronized (this.jogadores) {
				System.out.println("cmd desconectar <-----------------------------");
				this.jogadores.remove(host);
				this.situacao = SituacaoInicio.SERVIDOR_PARAR;
			}

			synchronized (this.saidas) {
				this.saidas.remove(saida);
				for (ObjectOutputStream enviarLista : this.saidas) {
					enviarLista.writeObject("CMD||RECEBERJOGADORES");
					enviarLista.writeObject(jogadores);
				}
			}

			this.vivo = false;
			saida.close();
			entrada.close();
			this.conexao.close();
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void levantarServidor() {
		System.out.println("Levantando servidor...");
		List<ObjectOutputStream> saidas = new ArrayList<ObjectOutputStream>();

		try {
			this.servidorPrincipal = new ServerSocket(12345);

			while (true) {
				// @SuppressWarnings("resource")
				// Instancia servidor ouvindo a porta 12345
				// Bloqueia at� receber um pedido de conexao
				Socket conexao = servidorPrincipal.accept();
				System.out.println("Servidor conectou");
				this.situacao = SituacaoInicio.CONECTADO;
				ServidorTCP novoServidorTCP = new ServidorTCP(conexao, saidas, this.principal, this.jogadores);
				novoServidorTCP.setSituacao(situacao);
				novoServidorTCP.start();
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void setSituacao(SituacaoInicio situacao) {
		this.situacao = situacao;
	}

	public void mostrarJogadores() {
		this.principal.limparJogadores();
		for (Jogador jogador : jogadores) {
			this.principal.adicionarJogador(jogador.getNomeJogador(), jogador.getCivilizacao(), jogador.getIp(),
					"aguardando iniciar... " + jogador.getId());
		}
		mostrarInimigos();
	}

	public void mostrarInimigos() {
		this.principal.limparInimigos();
		for (Jogador jogador : jogadores) {
			if (!this.principal.getJogadorPrincipal().getNomeJogador().equals(jogador.getNomeJogador())) {
				this.principal.adicionarInimigo(jogador);
			}
		}
	}

	public void encerrarServidor() {

		try {
			this.servidorPrincipal.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.vivo = false;
	}

	public int getIdJogadorHost() {
		return idJogadorHost;
	}

	public void setIdJogadorHost(int idJogadorHost) {
		this.idJogadorHost = idJogadorHost;
	}

	public void setVivo(boolean vivo) {
		this.vivo = vivo;
	}
}
