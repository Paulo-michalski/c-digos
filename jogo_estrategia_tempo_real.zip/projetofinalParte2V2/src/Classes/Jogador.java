package Classes;

import java.io.Serializable;

import tela.Principal;

public class Jogador implements Serializable {
	private static final long serialVersionUID = 4283883604103071976L;

	// Atributos
	private String nomeJogador;
	private String civilizacao;
	private String ipJogador;
	private int id;

	// Construtores
	public Jogador(String nome, String civilizacao, String ip, Principal principal) {
		this.nomeJogador = nome;
		this.civilizacao = civilizacao;
		this.ipJogador = ip;
	}

	public String getNomeJogador() {
		return nomeJogador;
	}

	public String getCivilizacao() {
		return civilizacao;
	}

	public String getIp() {
		return ipJogador;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}
