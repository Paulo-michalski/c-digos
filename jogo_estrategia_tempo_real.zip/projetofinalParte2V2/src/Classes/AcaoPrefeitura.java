package Classes;

public enum AcaoPrefeitura {
	PARADO, EVOLUINDO, CRIANDO;
}
