package Classes;

public enum AcaoTemplo {
	PARADO, EVOLUINDO;
}
